/* Handles block rendering and draws them to the screen*/
package vexaworld

import (
	"math"
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
)

func RenderBlock(screen *ebiten.Image, chunkX int, chunkY int, x int, y int, block int) {
	imagePath := "assets/" + strconv.Itoa(block) + ".png"
	image := Cache.GetImage(imagePath)
	op := &ebiten.DrawImageOptions{
		Filter: ebiten.FilterNearest,
	}
	drawX := int((chunkX*CHUNK_SIZE*BLOCK_SIZE)+(x*BLOCK_SIZE)) + int(math.Round(ViewOffsetX))
	drawY := int((chunkY*CHUNK_SIZE*BLOCK_SIZE)+(y*BLOCK_SIZE)) + int(math.Round(ViewOffsetY))
	op.GeoM.Translate(float64(drawX), float64(drawY))
	screen.DrawImage(image, op)
}

func (e *Entity) Draw(screen *ebiten.Image) {
	if !e.Visible {
		return
	}
	op := &ebiten.DrawImageOptions{
		Filter: ebiten.FilterNearest,
	}
	drawX := int(e.X*BLOCK_SIZE) + int(BLOCK_SIZE-e.imageW) + int(math.Round(ViewOffsetX))
	drawY := int(e.Y*BLOCK_SIZE) + int(BLOCK_SIZE-e.imageH) + int(math.Round(ViewOffsetY))
	if e.Flipped {
		op.GeoM.Scale(-1, 1)
		op.GeoM.Translate(BLOCK_SIZE, 0)
	}
	op.GeoM.Translate(float64(drawX), float64(drawY))
	screen.DrawImage(e.Image, op)
}
