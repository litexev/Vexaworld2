/* Actions and default key bindings */
package vexaworld

import (
	input "github.com/quasilyte/ebitengine-input"
)

const (
	ActionMoveLeft input.Action = iota
	ActionMoveRight
	ActionJump
)

var Keymap = input.Keymap{
	ActionMoveLeft:  {input.KeyGamepadLeft, input.KeyLeft, input.KeyA},
	ActionMoveRight: {input.KeyGamepadRight, input.KeyRight, input.KeyD},
	ActionJump:      {input.KeyGamepadUp, input.KeyUp, input.KeySpace, input.KeyW},
}
