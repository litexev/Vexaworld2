/* Base entity (drawing code is in render.go) */
package vexaworld

import (
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
)

type Entity struct {
	World   IWorld
	X       float64
	Y       float64
	Visible bool
	ImageId int
	Image   *ebiten.Image
	imageW  int
	imageH  int
	Flipped bool
}
type IWorld interface {
	GetBlock(x, y int) int
	GetGravity() float64
}

func CreateEntity(world IWorld, x float64, y float64, visible bool, imageId int) *Entity {
	return &Entity{
		World:   world,
		X:       x,
		Y:       y,
		Visible: visible,
		ImageId: imageId,
	}
}

func (e *Entity) Init() {
	if e.Visible && e.Image == nil {
		e.SetImageId(e.ImageId)
	}
}

func (e *Entity) Update(speed int) {
	// stub
}

func (e *Entity) SetImageId(id int) {
	e.ImageId = id
	imagePath := "assets/" + strconv.Itoa(id) + ".png"
	e.Image = Cache.GetImage(imagePath)
	e.imageW = e.Image.Bounds().Max.X
	e.imageH = e.Image.Bounds().Max.Y
}
