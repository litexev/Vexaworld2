/* Main game loop */
package vexaworld

import (
	"embed"
	"image"
	"log"
	"math"
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	input "github.com/quasilyte/ebitengine-input"
)

var FileSystem embed.FS
var InputHandler *input.Handler
var ScaleFactor float64 = 2.0
var CanvasWidth float64
var CanvasHeight float64

type Game struct {
	World       *World
	InputSystem input.System
}

func (g *Game) Update() error {
	g.InputSystem.Update()
	g.World.Update(1.0)
	return nil
}

func (g *Game) Draw(screen *ebiten.Image) {
	g.World.Draw(screen)
	fps := int(math.Round(ebiten.ActualFPS()))
	ebitenutil.DebugPrint(screen, "V5 PROTO "+strconv.Itoa(fps)+"\n"+strconv.Itoa(len(g.World.Chunks))+" chunks")
}

func (g *Game) Layout(w, h int) (int, int) { panic("not implemented") }

func (g *Game) LayoutF(logicWinWidth, logicWinHeight float64) (float64, float64) {
	deviceScale := ebiten.DeviceScaleFactor()
	CanvasWidth = math.Ceil(logicWinWidth * deviceScale / float64(ScaleFactor))
	CanvasHeight = math.Ceil(logicWinHeight * deviceScale / float64(ScaleFactor))
	return CanvasWidth, CanvasHeight
}

func StartGame(fs embed.FS) {
	// window options
	ebiten.SetWindowSize(1280, 960)
	ebiten.SetWindowTitle("Vexaworld 2")
	ebiten.SetWindowResizingMode(ebiten.WindowResizingModeEnabled)
	InitCache()

	// set icon
	icon, _ := fs.Open("assets/icon.png")
	img, _, _ := image.Decode(icon)
	ebiten.SetWindowIcon([]image.Image{img})

	game := Game{}
	FileSystem = fs

	// window scaling
	deviceScale := ebiten.DeviceScaleFactor()
	ScaleFactor = 2.0
	if deviceScale >= 1.5 {
		ScaleFactor = 3.0
	}
	if deviceScale >= 2.0 {
		ScaleFactor = 4.0
	}

	// init input
	game.InputSystem.Init(input.SystemConfig{
		DevicesEnabled: input.AnyDevice,
	})
	InputHandler = game.InputSystem.NewHandler(0, Keymap)

	// load test world
	game.World = CreateTestWorld()

	// debug unlimit framerate
	// ebiten.SetVsyncEnabled(false)
	// ebiten.SetTPS(-1)

	// run game
	if err := ebiten.RunGame(&game); err != nil {
		log.Fatal(err)
	}
}
