package vexaworld

import "math"

type BlockRange struct {
	TopX, TopY, BottomX, BottomY int
}

func (b BlockRange) Overlaps(other BlockRange) bool {
	return b.TopX <= other.BottomX && b.BottomX >= other.TopX && b.TopY <= other.BottomY && b.BottomY >= other.TopY
}

func (b BlockRange) Contains(x, y int) bool {
	return b.TopX <= x && b.BottomX >= x && b.TopY <= y && b.BottomY >= y
}

func CalculateVis() BlockRange {
	startX := -ViewOffsetX / BLOCK_SIZE
	startY := -ViewOffsetY / BLOCK_SIZE
	endX := (CanvasWidth - ViewOffsetX) / BLOCK_SIZE
	endY := (CanvasHeight - ViewOffsetY) / BLOCK_SIZE
	//return int(math.Floor(startX)), int(math.Floor(startY)), int(math.Ceil(endX)), int(math.Ceil(endY))
	return BlockRange{
		TopX:    int(math.Floor(startX)),
		TopY:    int(math.Floor(startY)),
		BottomX: int(math.Ceil(endX)),
		BottomY: int(math.Ceil(endY)),
	}
}
