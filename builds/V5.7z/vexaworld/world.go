/* The world contains all chunks and entities */
package vexaworld

import (
	"fmt"
	"image/color"
	"math"

	"github.com/hajimehoshi/ebiten/v2"
)

type World struct {
	Chunks   []Chunk
	Entities []IEntity
	BgColor  color.RGBA
	Gravity  float64
	Player   Player
}

var ViewOffsetX float64 = 0
var ViewOffsetY float64 = 0
var targetX float64 = 0
var targetY float64 = 0

func (w *World) Update(speed float64) {
	for _, entity := range w.Entities {
		entity.Update(speed)
	}
	w.Player.Update(speed)
	w.UpdateViewOffset(speed)
}

func (w *World) Draw(screen *ebiten.Image) {
	fmt.Println("draw world")
	screen.Fill(w.BgColor)
	vis := CalculateVis()
	for _, chunk := range w.Chunks {
		if !vis.Overlaps(chunk.GetVis()) {
			continue
		}
		chunk.Draw(screen, vis)
	}
	for _, entity := range w.Entities {
		entity.Draw(screen)
	}
	w.Player.Draw(screen)
}

func (w *World) GetBlock(x, y int) int {
	// fmt.Println("world GetBlock", x, y)
	chunk := w.GetChunkContainingPos(x, y)
	if chunk == nil {
		return 0
	}
	return chunk.GetBlockLocal(int(PositiveOnly(float64(x%CHUNK_SIZE))), int(PositiveOnly(float64(y%CHUNK_SIZE))))
}

func (w *World) GetChunkContainingPos(x, y int) *Chunk {
	chunkX := int(math.Ceil(float64(x)/float64(CHUNK_SIZE))) - 1
	chunkY := int(math.Ceil(float64(y)/float64(CHUNK_SIZE))) - 1
	return w.GetChunk(chunkX, chunkY)
}

func (w *World) GetChunk(x, y int) *Chunk {
	for _, chunk := range w.Chunks {
		if chunk.X == x && chunk.Y == y {
			return &chunk
		}
	}
	newChunk := GenerateChunk(x, y)
	w.Chunks = append(w.Chunks, newChunk)
	fmt.Println("generated chunk", newChunk.X, newChunk.Y)
	return &w.Chunks[len(w.Chunks)-1]
}

func (w *World) GetGravity() float64 {
	return w.Gravity
}

func (w *World) UpdateViewOffset(speed float64) {
	targetX = -w.Player.X*BLOCK_SIZE + float64(CanvasWidth)/4
	targetY = -w.Player.Y*BLOCK_SIZE + float64(CanvasHeight)/1.6
	ViewOffsetX += (targetX - ViewOffsetX) * 0.1 * speed
	ViewOffsetY += (targetY - ViewOffsetY) * 0.02 * speed
}

type IEntity interface {
	Init()
	Update(speed float64)
	SetImageId(id int)
	Draw(screen *ebiten.Image)
}

func CreateTestWorld() *World {
	world := World{
		Chunks:   []Chunk{},
		Entities: []IEntity{},
		BgColor:  color.RGBA{27, 27, 33, 255},
		Gravity:  DEFAULT_GRAVITY,
	}
	initChunk := GenerateChunk(0, 0)
	world.Chunks = append(world.Chunks, initChunk)

	player := CreatePlayer(&world, 8, 3, 5)
	world.Player = *player
	world.Player.Init()

	return &world
}
