package vexaworld

import (
	"math"

	"golang.org/x/exp/constraints"
)

type Number interface {
	constraints.Float | constraints.Integer
}

// Clamp returns f clamped to [low, high]
func Clamp(f, low, high float64) float64 {
	if f < low {
		return low
	}
	if f > high {
		return high
	}
	return f
}

func SnapToGrid(number, step int) int {
	return int(math.Floor(float64(number+(step/2)) / float64(step)))
}

func Lerp(a, b float64, t float64) float64 {
	return a + t*(b-a)
}

func EaseLerp(a, b float64, t float64) float64 {
	t = t*2 - 1
	if t < 0 {
		return a + (b-a)*(t*t+1)/2
	} else {
		t = t * 2
		return a + (b-a)*(1-t*t)/2
	}
}

func PositiveOnly(n float64) float64 {
	if n < 0 {
		return -n
	}
	return n
}
