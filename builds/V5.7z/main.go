/* Vexaworld Launcher */
package main

import (
	"embed"
	"vexaworld/vexaworld"
)

//go:embed assets/*
var assetFS embed.FS

func main() {
	vexaworld.StartGame(assetFS)
}
