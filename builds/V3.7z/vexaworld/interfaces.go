/* Common interfaces */
package vexaworld

import "github.com/hajimehoshi/ebiten/v2"

type IEntity interface {
	Init()
	Update(speed float64)
	SetImageId(id int)
	Draw(screen *ebiten.Image)
}

type IWorld interface {
	GetBlock(x, y int) int
	GetGravity() float64
}
