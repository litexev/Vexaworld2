/* Main game loop */
package vexaworld

import (
	"embed"
	"log"
	"math"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	input "github.com/quasilyte/ebitengine-input"
)

var FileSystem embed.FS
var InputHandler *input.Handler
var ScaleFactor float64 = 2.0

type Game struct {
	World       World
	InputSystem input.System
}

func (g *Game) Update() error {
	g.InputSystem.Update()
	g.World.Update(1.0)
	return nil
}

func (g *Game) Draw(screen *ebiten.Image) {
	g.World.Draw(screen)
	ebitenutil.DebugPrint(screen, "V3")
}

func (g *Game) Layout(w, h int) (int, int) { panic("not implemented") }

func (g *Game) LayoutF(logicWinWidth, logicWinHeight float64) (float64, float64) {
	deviceScale := ebiten.DeviceScaleFactor()
	canvasWidth := math.Ceil(logicWinWidth * deviceScale / float64(ScaleFactor))
	canvasHeight := math.Ceil(logicWinHeight * deviceScale / float64(ScaleFactor))
	g.World.SetWindowSize(int(canvasWidth), int(canvasHeight))
	return canvasWidth, canvasHeight
}

func StartGame(fs embed.FS) {
	// window options
	ebiten.SetWindowSize(1600, 900)
	ebiten.SetWindowTitle("Vexaworld 2")
	InitCache()
	game := Game{}
	FileSystem = fs

	// window scaling
	deviceScale := ebiten.DeviceScaleFactor()
	ScaleFactor = 2.0
	if deviceScale >= 1.5 {
		ScaleFactor = 3.0
	}
	if deviceScale >= 2.0 {
		ScaleFactor = 4.0
	}

	// init input
	game.InputSystem.Init(input.SystemConfig{
		DevicesEnabled: input.AnyDevice,
	})
	InputHandler = game.InputSystem.NewHandler(0, Keymap)

	// load test world
	game.World = CreateTestWorld()

	// run game
	if err := ebiten.RunGame(&game); err != nil {
		log.Fatal(err)
	}
}
