/* The image cache stores loaded images */
package vexaworld

import (
	"sync"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
)

type ImageCache struct {
	images map[string]*ebiten.Image
	mu     sync.RWMutex
}

var Cache ImageCache

func InitCache() {
	Cache = ImageCache{
		images: make(map[string]*ebiten.Image),
		mu:     sync.RWMutex{},
	}
}

func (ic *ImageCache) LoadImage(filePath string) *ebiten.Image {
	ic.mu.RLock()
	cachedImage, exists := ic.images[filePath]
	ic.mu.RUnlock()

	if exists {
		return cachedImage
	}

	image, _, err := ebitenutil.NewImageFromFileSystem(FileSystem, filePath)
	if err != nil {
		return ic.LoadImage("assets/error.png")
	}

	ic.mu.Lock()
	ic.images[filePath] = image
	ic.mu.Unlock()

	return image
}
