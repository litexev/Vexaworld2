/* Procedural world generation */
package vexaworld

func WorldGen(x int, y int) int {
	// grass
	if y == 7 {
		return 1
	}
	if y > 7 {
		return 2
	}
	// blue blocks
	if x == 2 && y == 6 || x == 2 && y == 5 || x == 5 && y == 6 {
		return 4
	}
	return 0
}

func GenerateChunk(x int, y int) Chunk {
	startX := x * CHUNK_SIZE
	startY := y * CHUNK_SIZE
	grid := [CHUNK_SIZE][CHUNK_SIZE]int{}
	for dx := 0; dx < CHUNK_SIZE; dx++ {
		for dy := 0; dy < CHUNK_SIZE; dy++ {
			grid[dx][dy] = WorldGen(startX+dx, startY+dy)
		}
	}
	return Chunk{
		Blocks: grid,
		X:      x,
		Y:      y,
	}
}
