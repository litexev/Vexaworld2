/* Vexaworld main player with controls */
package vexaworld

type Player struct {
	PhysEntity
}

func CreatePlayer(world IWorld, x float64, y float64, imageId int) *Player {
	return &Player{
		PhysEntity: *CreatePhysEntity(world, x, y, imageId),
	}
}

func (p *Player) Update(speed float64) {
	p.PhysEntity.Update(speed)
	if InputHandler.ActionIsPressed(ActionMoveLeft) {
		p.VelX = -SIDE_VEL
	}
	if InputHandler.ActionIsPressed(ActionMoveRight) {
		p.VelX = SIDE_VEL
	}
	if InputHandler.ActionIsPressed(ActionJump) {
		if p.Grounded {
			p.VelY = -JUMP_VEL
			p.Grounded = false
		}
	}
}
