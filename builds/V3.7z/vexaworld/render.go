/* Handles block rendering and draws them to the screen*/
package vexaworld

import (
	"math"
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
)

func RenderBlock(screen *ebiten.Image, chunkX int, chunkY int, x int, y int, block int) {
	imagePath := "assets/" + strconv.Itoa(block) + ".png"
	image := Cache.LoadImage(imagePath)
	op := &ebiten.DrawImageOptions{
		Filter: ebiten.FilterNearest,
	}
	drawX := int((chunkX*CHUNK_SIZE)+(x*BLOCK_SIZE)) + int(math.Round(ViewOffsetX))
	drawY := int((chunkY*CHUNK_SIZE)+(y*BLOCK_SIZE)) + int(math.Round(ViewOffsetY))
	op.GeoM.Translate(float64(drawX), float64(drawY))
	screen.DrawImage(image, op)
}

func (e *Entity) Draw(screen *ebiten.Image) {
	if !e.Visible {
		return
	}
	op := &ebiten.DrawImageOptions{
		Filter: ebiten.FilterNearest,
	}
	drawX := int(e.X*BLOCK_SIZE) + int(math.Round(ViewOffsetX))
	drawY := int(e.Y*BLOCK_SIZE) + int(math.Round(ViewOffsetY))
	op.GeoM.Translate(float64(drawX), float64(drawY))
	screen.DrawImage(e.Image, op)
}
