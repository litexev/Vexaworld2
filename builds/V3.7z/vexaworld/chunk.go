/* Chunks divide up the world into tiles for efficiency */
package vexaworld

import (
	"github.com/hajimehoshi/ebiten/v2"
)

type Chunk struct {
	Blocks [CHUNK_SIZE][CHUNK_SIZE]int
	X      int
	Y      int
}

func (c Chunk) Draw(screen *ebiten.Image) {
	for dx := 0; dx < CHUNK_SIZE; dx++ {
		for dy := 0; dy < CHUNK_SIZE; dy++ {
			block := c.Blocks[dx][dy]
			if block == 0 {
				continue
			}
			RenderBlock(screen, c.X, c.Y, dx, dy, block)
		}
	}
}

func (c Chunk) GetBlockLocal(x int, y int) int {
	return c.Blocks[x][y]
}
